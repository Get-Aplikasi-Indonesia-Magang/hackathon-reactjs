import React from "react";

class StateFullComponent extends React.Component {
  render() {
    return <p>StateFull Component</p>;
  }
}

export default StateFullComponent;
